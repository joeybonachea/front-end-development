﻿//#### LAB 4 - FUNCTIONS ####
//PART 1:  PROGRAM ALERT FUNCTION


//################## CREATE YOUR FUNCTION
function coursePopup(courseCode, courseName) {
    alert("The course code " + courseCode + " is " + courseName + ".");
}




//################## TEST YOUR FUNCTION
coursePopup("HTTP-5121", "Web Design");
coursePopup("HTTP-5122", "Front-End Web Development 1");
coursePopup("IXD-5106", "Intro to Interactive Design");