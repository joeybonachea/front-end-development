//ALL VARIABLES ARE DECLARED HERE;

var firstHello = " Hello World ";
var firstName = " Beti "; //string var
var age = 26; //number var
var daysYear = 365; //days in a year
var multiple = daysYear * age; //product of days in a year by age
var daysOldText = " days old... more or less.";
//alert(firstHello);

//alert(multiple);

alert(firstName + "is " + multiple + daysOldText);

