//LAB 3 - ARRAYS & LOOPS - PART 1


//ARRAY OF FRUITS
var fruits = ["Apple", "Banana", "Mango", "Orange", "Pineapple"]
var fruits2 = fruits.splice (1,1,"kiwi");
console.log (fruits);
//OUTPUT ONE FRUIT FROM THE ARRAY IN POPUP BOX
alert(fruits [0]);